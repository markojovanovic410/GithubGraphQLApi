import './style/app.less';
import RepositoryTable from './component/RepositoryTable'
function App() {

  return (
    <div className="App">
        <RepositoryTable/>
    </div>
  );
}

export default App;
