
const dataSource = [
    { name:'react',    stars:32030,    forks:343,    }                                                                                                                                                                                                                                                                                                                                                                                                                                          
];
export default dataSource;